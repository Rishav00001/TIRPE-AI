import { Sidebar } from "../components/Sidebar";
import { Panel, PanelHeader, PanelTitle, PanelContent } from "../components/Panel";
import { Send, ArrowLeft, Bot, User } from "lucide-react";
import { useState } from "react";

interface Message {
  role: "user" | "assistant";
  content: string;
  timestamp: string;
}

const initialMessages: Message[] = [
  {
    role: "assistant",
    content: "Hello! I'm TIRPE Copilot. I can help you understand risk predictions, analyze trends, and provide actionable recommendations. Ask me anything about tourism data for Jammu region.",
    timestamp: "14:20",
  },
];

export function Chatbot() {
  const [messages, setMessages] = useState<Message[]>(initialMessages);
  const [input, setInput] = useState("");
  const [selectedLocation, setSelectedLocation] = useState("vaishno-devi");

  const locations = [
    { id: "vaishno-devi", name: "Vaishno Devi" },
    { id: "patnitop", name: "Patnitop" },
    { id: "raghunath-temple", name: "Raghunath Temple" },
    { id: "all", name: "All Locations" },
  ];

  const handleSend = () => {
    if (!input.trim()) return;

    const userMessage: Message = {
      role: "user",
      content: input,
      timestamp: new Date().toLocaleTimeString("en-US", { hour: "2-digit", minute: "2-digit", hour12: false }),
    };

    setMessages((prev) => [...prev, userMessage]);

    // Simulate AI response
    setTimeout(() => {
      const assistantMessage: Message = {
        role: "assistant",
        content: generateResponse(input),
        timestamp: new Date().toLocaleTimeString("en-US", { hour: "2-digit", minute: "2-digit", hour12: false }),
      };
      setMessages((prev) => [...prev, assistantMessage]);
    }, 800);

    setInput("");
  };

  const generateResponse = (query: string): string => {
    const lowerQuery = query.toLowerCase();

    if (lowerQuery.includes("risk") || lowerQuery.includes("vaishno")) {
      return "Vaishno Devi currently has a critical risk score of 85/100. The main contributing factors are:\n\n1. **Footfall Pressure (35 points)**: Predicted 42,000 visitors vs 35,000 capacity\n2. **Weather Risk (22 points)**: Heavy rainfall expected at 15:30 (22mm)\n3. **AQI Impact (12 points)**: Moderate air quality at 152\n4. **Social Spike (10 points)**: +42% increase in last 3 hours\n\nI recommend activating shuttle services and implementing staggered entry to manage the crowd safely.";
    }

    if (lowerQuery.includes("weather") || lowerQuery.includes("rain")) {
      return "Weather forecast for Vaishno Devi:\n\n• **Next 3 hours**: Partly cloudy, 18°C\n• **15:30-18:00**: Heavy rainfall (22mm expected)\n• **Evening**: Light showers continuing\n\nThis weather poses additional safety risks for pilgrims. I recommend issuing weather advisories and considering temporary access restrictions during peak rainfall.";
    }

    if (lowerQuery.includes("mitigation") || lowerQuery.includes("recommend")) {
      return "Based on current conditions, here are my recommendations:\n\n**Immediate Actions (Next 2 hours):**\n1. Activate shuttle services from parking areas\n2. Implement staggered entry slots (08:00-10:00, 10:00-12:00)\n3. Send weather advisory notifications to registered visitors\n\n**Alternate Solutions:**\n• Redirect visitors to Patnitop (45% capacity utilization)\n• Increase parking restrictions in congested zones\n• Deploy additional staff for crowd management\n\nThese measures could reduce risk from 85 to approximately 58.";
    }

    if (lowerQuery.includes("capacity") || lowerQuery.includes("footfall")) {
      return "Capacity analysis for Vaishno Devi:\n\n• **Current capacity**: 35,000 visitors\n• **Predicted footfall (16:00)**: 42,000 visitors\n• **Utilization**: 120% (over capacity by 7,000)\n• **Peak time**: 16:00-17:00 today\n\nHistorical data shows that weekends in February typically see 15-20% higher footfall. Combined with favorable weather (before rain), we're seeing increased visitor interest via social media tracking.";
    }

    if (lowerQuery.includes("compare") || lowerQuery.includes("patnitop")) {
      return "Comparison of top tourism sites:\n\n**Vaishno Devi:**\n• Risk: 85 (Red) | Predicted: 42,000 | Capacity: 120%\n\n**Patnitop:**\n• Risk: 45 (Yellow) | Predicted: 8,500 | Capacity: 71%\n\n**Raghunath Temple:**\n• Risk: 28 (Green) | Predicted: 2,200 | Capacity: 44%\n\nPatnitop and Raghunath Temple have significant remaining capacity. Consider promoting these alternatives to balance visitor distribution.";
    }

    return "I can help you with:\n• Risk analysis and predictions\n• Weather and AQI impact assessment\n• Capacity utilization insights\n• Mitigation recommendations\n• Historical trend analysis\n\nWhat would you like to know?";
  };

  return (
    <div className="flex h-screen bg-slate-50">
      <Sidebar />
      <div className="flex-1 overflow-hidden flex flex-col">
        {/* Header */}
        <div className="bg-white border-b border-slate-200 p-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <button
                onClick={() => window.location.href = "/analytics"}
                className="flex items-center gap-2 text-sm text-slate-600 hover:text-slate-900 transition-colors"
              >
                <ArrowLeft className="w-4 h-4" />
                Back to Analytics
              </button>
              <div className="h-6 w-px bg-slate-300"></div>
              <div>
                <h2 className="font-semibold text-slate-900">TIRPE Analytics Chatbot</h2>
                <p className="text-xs text-slate-600">Ask questions in natural language</p>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <select
                value={selectedLocation}
                onChange={(e) => setSelectedLocation(e.target.value)}
                className="px-3 py-1.5 border border-slate-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                {locations.map((loc) => (
                  <option key={loc.id} value={loc.id}>
                    {loc.name}
                  </option>
                ))}
              </select>
              <div className="flex items-center gap-2 px-3 py-1.5 bg-green-100 text-green-800 rounded-lg text-xs font-medium">
                <div className="w-2 h-2 bg-green-600 rounded-full"></div>
                OpenAI Active
              </div>
            </div>
          </div>
        </div>

        {/* Chat Area */}
        <div className="flex-1 overflow-auto p-6">
          <div className="max-w-3xl mx-auto space-y-4">
            {messages.map((message, index) => (
              <div
                key={index}
                className={`flex gap-3 ${message.role === "user" ? "justify-end" : "justify-start"}`}
              >
                {message.role === "assistant" && (
                  <div className="w-8 h-8 bg-blue-600 rounded-full flex items-center justify-center flex-shrink-0">
                    <Bot className="w-5 h-5 text-white" />
                  </div>
                )}
                <div
                  className={`max-w-xl ${
                    message.role === "user"
                      ? "bg-blue-600 text-white"
                      : "bg-white border border-slate-200 text-slate-900"
                  } rounded-lg p-4`}
                >
                  <div className="text-sm whitespace-pre-line">{message.content}</div>
                  <div
                    className={`text-xs mt-2 ${
                      message.role === "user" ? "text-blue-100" : "text-slate-500"
                    }`}
                  >
                    {message.timestamp}
                  </div>
                </div>
                {message.role === "user" && (
                  <div className="w-8 h-8 bg-slate-700 rounded-full flex items-center justify-center flex-shrink-0">
                    <User className="w-5 h-5 text-white" />
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Input Area */}
        <div className="bg-white border-t border-slate-200 p-4">
          <div className="max-w-3xl mx-auto">
            <div className="flex gap-3">
              <input
                type="text"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && handleSend()}
                placeholder="Ask about risk predictions, weather impact, capacity analysis..."
                className="flex-1 px-4 py-3 border border-slate-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
              <button
                onClick={handleSend}
                className="px-6 py-3 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition-colors flex items-center gap-2"
              >
                <Send className="w-4 h-4" />
                Send
              </button>
            </div>
            <div className="mt-2 text-xs text-slate-500">
              Try asking: "What's the risk at Vaishno Devi?" or "What mitigation actions do you recommend?"
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
