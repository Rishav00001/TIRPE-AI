import { Sidebar } from "../components/Sidebar";
import { Database, Cloud, Cpu, Brain, AlertTriangle, Shield, BarChart3, MonitorCheck } from "lucide-react";

export function Flowchart() {
  return (
    <div className="flex h-screen bg-slate-50">
      <Sidebar />
      <div className="flex-1 overflow-auto">
        <div className="p-6">
          <div className="mb-6">
            <h2 className="text-2xl font-semibold text-slate-900">System Architecture Flowchart</h2>
            <p className="text-sm text-slate-600 mt-1">TIRPE AI - Tourism Intelligence & Risk Prediction Engine</p>
          </div>

          {/* Legend */}
          <div className="mb-6 flex items-center gap-6 text-xs">
            <div className="flex items-center gap-2">
              <div className="w-4 h-4 rounded bg-green-100 border-2 border-green-500"></div>
              <span className="text-slate-700">Green (Risk &lt; 40)</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-4 h-4 rounded bg-yellow-100 border-2 border-yellow-500"></div>
              <span className="text-slate-700">Yellow (Risk 40-70)</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-4 h-4 rounded bg-red-100 border-2 border-red-500"></div>
              <span className="text-slate-700">Red (Risk &gt; 70)</span>
            </div>
          </div>

          {/* Flowchart */}
          <div className="bg-white p-8 rounded-lg border border-slate-200">
            {/* Data Inputs */}
            <div className="mb-8">
              <div className="flex items-center gap-2 mb-4">
                <Database className="w-5 h-5 text-slate-700" />
                <h3 className="font-semibold text-slate-900">1. Data Inputs</h3>
              </div>
              <div className="grid grid-cols-5 gap-3">
                <div className="bg-slate-50 border border-slate-300 rounded-lg p-3 text-center">
                  <div className="text-xs font-medium text-slate-700">Historical Footfall</div>
                  <div className="text-xs text-slate-500 mt-1">PostgreSQL</div>
                </div>
                <div className="bg-slate-50 border border-slate-300 rounded-lg p-3 text-center">
                  <div className="text-xs font-medium text-slate-700">Live Weather</div>
                  <div className="text-xs text-slate-500 mt-1">OpenWeather API</div>
                </div>
                <div className="bg-slate-50 border border-slate-300 rounded-lg p-3 text-center">
                  <div className="text-xs font-medium text-slate-700">AQI Data</div>
                  <div className="text-xs text-slate-500 mt-1">OpenWeather API</div>
                </div>
                <div className="bg-slate-50 border border-slate-300 rounded-lg p-3 text-center">
                  <div className="text-xs font-medium text-slate-700">Social Media</div>
                  <div className="text-xs text-slate-500 mt-1">Spike Index</div>
                </div>
                <div className="bg-slate-50 border border-slate-300 rounded-lg p-3 text-center">
                  <div className="text-xs font-medium text-slate-700">Traffic Index</div>
                  <div className="text-xs text-slate-500 mt-1">Live Feed</div>
                </div>
              </div>
              <div className="flex justify-center mt-3">
                <div className="text-slate-400 text-2xl">↓</div>
              </div>
            </div>

            {/* Backend Processing */}
            <div className="mb-8">
              <div className="flex items-center gap-2 mb-4">
                <Cpu className="w-5 h-5 text-slate-700" />
                <h3 className="font-semibold text-slate-900">2. Backend Processing</h3>
              </div>
              <div className="bg-slate-700 text-white rounded-lg p-4">
                <div className="text-center mb-3 text-sm font-medium">Node.js + Express</div>
                <div className="grid grid-cols-3 gap-3 text-xs">
                  <div className="bg-slate-600 rounded p-2 text-center">Validation Middleware (Zod)</div>
                  <div className="bg-slate-600 rounded p-2 text-center">Feature Preparation</div>
                  <div className="bg-slate-600 rounded p-2 text-center">Weather/AQI Enrichment</div>
                </div>
              </div>
              <div className="flex justify-center mt-3">
                <div className="text-slate-400 text-2xl">↓</div>
              </div>
            </div>

            {/* Prediction Layer */}
            <div className="mb-8">
              <div className="flex items-center gap-2 mb-4">
                <Brain className="w-5 h-5 text-slate-700" />
                <h3 className="font-semibold text-slate-900">3. AI Prediction Layer</h3>
              </div>
              <div className="bg-blue-50 border-2 border-blue-400 rounded-lg p-4">
                <div className="text-center mb-3 text-sm font-medium text-blue-900">AI Provider Switch (ENV Config)</div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="bg-white border border-blue-300 rounded-lg p-3">
                    <div className="text-xs font-medium text-blue-900 text-center mb-2">Primary: OpenAI</div>
                    <div className="text-xs text-slate-600">
                      • GPT-based predictions<br />
                      • Natural language outputs<br />
                      • High accuracy inference
                    </div>
                  </div>
                  <div className="bg-white border border-blue-300 rounded-lg p-3">
                    <div className="text-xs font-medium text-blue-900 text-center mb-2">Fallback: Local Model</div>
                    <div className="text-xs text-slate-600">
                      • FastAPI + RandomForest<br />
                      • Scikit-learn training<br />
                      • Offline capability
                    </div>
                  </div>
                </div>
              </div>
              <div className="flex justify-center mt-3">
                <div className="text-slate-400 text-2xl">↓</div>
              </div>
            </div>

            {/* Risk Engine */}
            <div className="mb-8">
              <div className="flex items-center gap-2 mb-4">
                <AlertTriangle className="w-5 h-5 text-slate-700" />
                <h3 className="font-semibold text-slate-900">4. Risk Engine</h3>
              </div>
              <div className="bg-amber-50 border-2 border-amber-400 rounded-lg p-4">
                <div className="grid grid-cols-3 gap-3 text-xs">
                  <div className="bg-white border border-amber-300 rounded p-2">
                    <div className="font-medium text-amber-900 mb-1">Risk Score Formula</div>
                    <div className="text-slate-600">0-100 scale calculation</div>
                  </div>
                  <div className="bg-white border border-amber-300 rounded p-2">
                    <div className="font-medium text-amber-900 mb-1">Sustainability Score</div>
                    <div className="text-slate-600">Environmental impact</div>
                  </div>
                  <div className="bg-white border border-amber-300 rounded p-2">
                    <div className="font-medium text-amber-900 mb-1">Classification</div>
                    <div className="text-slate-600">Green / Yellow / Red</div>
                  </div>
                </div>
              </div>
              <div className="flex justify-center mt-3">
                <div className="text-slate-400 text-2xl">↓</div>
              </div>
            </div>

            {/* Mitigation Engine */}
            <div className="mb-8">
              <div className="flex items-center gap-2 mb-4">
                <Shield className="w-5 h-5 text-slate-700" />
                <h3 className="font-semibold text-slate-900">5. Mitigation Engine</h3>
              </div>
              <div className="bg-green-50 border-2 border-green-400 rounded-lg p-4">
                <div className="grid grid-cols-4 gap-2 text-xs">
                  <div className="bg-white border border-green-300 rounded p-2 text-center">
                    <div className="font-medium text-green-900">Alternate Locations</div>
                  </div>
                  <div className="bg-white border border-green-300 rounded p-2 text-center">
                    <div className="font-medium text-green-900">Staggered Entry</div>
                  </div>
                  <div className="bg-white border border-green-300 rounded p-2 text-center">
                    <div className="font-medium text-green-900">Shuttle Activation</div>
                  </div>
                  <div className="bg-white border border-green-300 rounded p-2 text-center">
                    <div className="font-medium text-green-900">Parking Restrictions</div>
                  </div>
                </div>
              </div>
              <div className="flex justify-center mt-3">
                <div className="text-slate-400 text-2xl">↓</div>
              </div>
            </div>

            {/* API Layer */}
            <div className="mb-8">
              <div className="flex items-center gap-2 mb-4">
                <Cloud className="w-5 h-5 text-slate-700" />
                <h3 className="font-semibold text-slate-900">6. API Layer (REST Endpoints)</h3>
              </div>
              <div className="grid grid-cols-6 gap-2 text-xs">
                <div className="bg-indigo-50 border border-indigo-300 rounded p-2 text-center text-indigo-900 font-medium">
                  /dashboard
                </div>
                <div className="bg-indigo-50 border border-indigo-300 rounded p-2 text-center text-indigo-900 font-medium">
                  /analytics/:id
                </div>
                <div className="bg-indigo-50 border border-indigo-300 rounded p-2 text-center text-indigo-900 font-medium">
                  /risk/:id
                </div>
                <div className="bg-indigo-50 border border-indigo-300 rounded p-2 text-center text-indigo-900 font-medium">
                  /mitigation/:id
                </div>
                <div className="bg-indigo-50 border border-indigo-300 rounded p-2 text-center text-indigo-900 font-medium">
                  /chat
                </div>
                <div className="bg-indigo-50 border border-indigo-300 rounded p-2 text-center text-indigo-900 font-medium">
                  /console/overview
                </div>
              </div>
              <div className="flex justify-center mt-3">
                <div className="text-slate-400 text-2xl">↓</div>
              </div>
            </div>

            {/* Frontend Dashboard */}
            <div className="mb-8">
              <div className="flex items-center gap-2 mb-4">
                <BarChart3 className="w-5 h-5 text-slate-700" />
                <h3 className="font-semibold text-slate-900">7. Frontend Dashboard</h3>
              </div>
              <div className="bg-purple-50 border-2 border-purple-400 rounded-lg p-4">
                <div className="text-center mb-3 text-sm font-medium text-purple-900">React + Tailwind CSS</div>
                <div className="grid grid-cols-4 gap-2 text-xs">
                  <div className="bg-white border border-purple-300 rounded p-2 text-center">Risk Heatmap</div>
                  <div className="bg-white border border-purple-300 rounded p-2 text-center">Forecast Charts</div>
                  <div className="bg-white border border-purple-300 rounded p-2 text-center">Weather Watchlist</div>
                  <div className="bg-white border border-purple-300 rounded p-2 text-center">Plain-Language AI</div>
                </div>
                <div className="grid grid-cols-2 gap-2 mt-2 text-xs">
                  <div className="bg-white border border-purple-300 rounded p-2 text-center">Analytics Chatbot</div>
                  <div className="bg-white border border-purple-300 rounded p-2 text-center">Operations Console</div>
                </div>
              </div>
              <div className="flex justify-center mt-3">
                <div className="text-slate-400 text-2xl">↓</div>
              </div>
            </div>

            {/* Decision Output */}
            <div>
              <div className="flex items-center gap-2 mb-4">
                <MonitorCheck className="w-5 h-5 text-slate-700" />
                <h3 className="font-semibold text-slate-900">8. Decision Output</h3>
              </div>
              <div className="bg-slate-900 text-white rounded-lg p-4">
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div className="text-center">
                    <div className="font-medium mb-2">Actionable Recommendations</div>
                    <div className="text-xs text-slate-300">
                      For tourism authorities and site managers
                    </div>
                  </div>
                  <div className="text-center">
                    <div className="font-medium mb-2">Early Warning System</div>
                    <div className="text-xs text-slate-300">
                      6-12 hours advance prediction
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Technical Notes */}
          <div className="mt-6 bg-blue-50 border border-blue-200 rounded-lg p-4 text-xs text-blue-900">
            <div className="font-medium mb-2">Technical Architecture Notes:</div>
            <ul className="space-y-1 list-disc list-inside text-blue-800">
              <li>Backend validation uses Zod for type-safe request schemas</li>
              <li>Redis optional caching layer for API response optimization</li>
              <li>Environment-based feature flags for AI provider switching</li>
              <li>Leaflet/OpenStreetMap for interactive risk visualization</li>
              <li>Recharts library for data-driven chart components</li>
              <li>Chatbot maintains conversation memory for context-aware responses</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
}
