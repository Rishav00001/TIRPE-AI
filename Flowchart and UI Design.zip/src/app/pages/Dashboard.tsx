import { Sidebar } from "../components/Sidebar";
import { Panel, PanelHeader, PanelTitle, PanelContent } from "../components/Panel";
import { KPICard } from "../components/KPICard";
import { RiskPill } from "../components/RiskPill";
import { LogList } from "../components/LogList";
import { RiskMap } from "../components/RiskMap";
import { LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";
import { AlertTriangle, Cloud, Wind, MessageSquare } from "lucide-react";

const riskTrendData = [
  { time: "00:00", risk: 32 },
  { time: "04:00", risk: 28 },
  { time: "08:00", risk: 45 },
  { time: "12:00", risk: 72 },
  { time: "16:00", risk: 85 },
  { time: "20:00", risk: 68 },
  { time: "24:00", risk: 42 },
];

const locations = [
  { id: 1, name: "Vaishno Devi", lat: 33.0307, lng: 74.9497, risk: 85, predicted: 42000, capacity: 35000 },
  { id: 2, name: "Patnitop", lat: 33.0694, lng: 75.3286, risk: 45, predicted: 8500, capacity: 12000 },
  { id: 3, name: "Raghunath Temple", lat: 32.7333, lng: 74.8667, risk: 28, predicted: 2200, capacity: 5000 },
];

const logs = [
  { time: "14:23", message: "Risk alert triggered for Vaishno Devi (85)", type: "error" as const },
  { time: "14:15", message: "Weather advisory: Heavy rainfall expected", type: "warning" as const },
  { time: "14:10", message: "OpenAI API call successful (218ms)", type: "info" as const },
  { time: "14:05", message: "Social media spike detected (+42%)", type: "warning" as const },
  { time: "14:00", message: "Database sync completed", type: "info" as const },
];

export function Dashboard() {
  return (
    <div className="flex h-screen bg-slate-50">
      <Sidebar />
      <div className="flex-1 overflow-auto">
        <div className="p-6">
          <div className="mb-6">
            <h2 className="text-2xl font-semibold text-slate-900">Tourism Risk Dashboard</h2>
            <p className="text-sm text-slate-600 mt-1">Real-time intelligence for Jammu region</p>
          </div>

          {/* KPI Row */}
          <div className="grid grid-cols-4 gap-4 mb-6">
            <KPICard label="Highest Risk Site" value="Vaishno Devi" sublabel="Risk: 85 (Red)" />
            <KPICard label="Average Risk" value="52.7" sublabel="Across 12 sites" />
            <KPICard label="Red Alerts" value="3" sublabel="Active warnings" />
            <KPICard label="Sustainability Score" value="68%" sublabel="Target: 75%" />
          </div>

          <div className="grid grid-cols-3 gap-6">
            {/* Left Column */}
            <div className="col-span-2 space-y-6">
              {/* Map */}
              <Panel>
                <PanelHeader>
                  <PanelTitle>Jammu Region Heat Map</PanelTitle>
                </PanelHeader>
                <PanelContent>
                  <div className="h-80 rounded-lg overflow-hidden border border-slate-200">
                    <RiskMap locations={locations} />
                  </div>
                </PanelContent>
              </Panel>

              {/* Predicted vs Capacity */}
              <Panel>
                <PanelHeader>
                  <PanelTitle>Predicted Footfall vs Capacity</PanelTitle>
                </PanelHeader>
                <PanelContent>
                  <ResponsiveContainer width="100%" height={200}>
                    <BarChart data={locations}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                      <XAxis dataKey="name" tick={{ fontSize: 12 }} />
                      <YAxis tick={{ fontSize: 12 }} />
                      <Tooltip />
                      <Bar dataKey="predicted" fill="#3b82f6" name="Predicted" />
                      <Bar dataKey="capacity" fill="#94a3b8" name="Capacity" />
                    </BarChart>
                  </ResponsiveContainer>
                </PanelContent>
              </Panel>

              {/* Risk Trend */}
              <Panel>
                <PanelHeader>
                  <PanelTitle>24-Hour Risk Trend</PanelTitle>
                </PanelHeader>
                <PanelContent>
                  <ResponsiveContainer width="100%" height={200}>
                    <LineChart data={riskTrendData}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                      <XAxis dataKey="time" tick={{ fontSize: 12 }} />
                      <YAxis domain={[0, 100]} tick={{ fontSize: 12 }} />
                      <Tooltip />
                      <Line type="monotone" dataKey="risk" stroke="#ef4444" strokeWidth={2} />
                    </LineChart>
                  </ResponsiveContainer>
                </PanelContent>
              </Panel>

              {/* Plain Language Summary */}
              <Panel className="bg-blue-50 border-blue-200">
                <PanelHeader>
                  <PanelTitle className="text-blue-900">Plain-Language Summary for Judges</PanelTitle>
                </PanelHeader>
                <PanelContent>
                  <p className="text-sm text-blue-800">
                    <strong>Vaishno Devi</strong> is at <strong>critical risk (85/100)</strong> with predicted footfall of <strong>42,000 exceeding capacity by 20%</strong>. 
                    Weather conditions show heavy rainfall in the next 6 hours, and AQI is moderate (152). Social media activity has spiked +42% indicating high tourist interest.
                  </p>
                  <p className="text-sm text-blue-800 mt-2">
                    <strong>Recommended actions:</strong> Activate shuttle services, implement staggered entry from 08:00-10:00, and redirect visitors to Patnitop (45% capacity utilization).
                  </p>
                </PanelContent>
              </Panel>

              {/* Chatbot CTA */}
              <Panel className="bg-slate-700 border-slate-600">
                <div className="flex items-center justify-between">
                  <div>
                    <div className="flex items-center gap-2 mb-1">
                      <MessageSquare className="w-5 h-5 text-blue-400" />
                      <PanelTitle className="text-white">Ask TIRPE Copilot</PanelTitle>
                    </div>
                    <p className="text-sm text-slate-300">Get natural language insights from your data</p>
                  </div>
                  <button 
                    onClick={() => window.location.href = "/chatbot"}
                    className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white text-sm rounded-lg transition-colors"
                  >
                    Open Chatbot
                  </button>
                </div>
              </Panel>
            </div>

            {/* Right Column - Operations Console */}
            <div className="space-y-6">
              {/* Weather Watchlist */}
              <Panel>
                <PanelHeader>
                  <PanelTitle>Weather + AQI Watchlist</PanelTitle>
                </PanelHeader>
                <PanelContent className="space-y-3">
                  <div className="flex items-start gap-3 pb-3 border-b border-slate-100">
                    <Cloud className="w-5 h-5 text-slate-400 mt-0.5" />
                    <div className="flex-1">
                      <div className="text-sm font-medium text-slate-900">Vaishno Devi</div>
                      <div className="text-xs text-slate-600">Heavy rain (22mm), 18°C</div>
                      <div className="text-xs text-yellow-700 mt-1">AQI: 152 (Moderate)</div>
                    </div>
                  </div>
                  <div className="flex items-start gap-3 pb-3 border-b border-slate-100">
                    <Wind className="w-5 h-5 text-slate-400 mt-0.5" />
                    <div className="flex-1">
                      <div className="text-sm font-medium text-slate-900">Patnitop</div>
                      <div className="text-xs text-slate-600">Partly cloudy, 14°C</div>
                      <div className="text-xs text-green-700 mt-1">AQI: 68 (Good)</div>
                    </div>
                  </div>
                  <div className="flex items-start gap-3">
                    <Cloud className="w-5 h-5 text-slate-400 mt-0.5" />
                    <div className="flex-1">
                      <div className="text-sm font-medium text-slate-900">Raghunath Temple</div>
                      <div className="text-xs text-slate-600">Clear, 21°C</div>
                      <div className="text-xs text-green-700 mt-1">AQI: 82 (Good)</div>
                    </div>
                  </div>
                </PanelContent>
              </Panel>

              {/* Runtime Status */}
              <Panel className="bg-slate-50">
                <PanelHeader>
                  <PanelTitle>Runtime Status</PanelTitle>
                </PanelHeader>
                <PanelContent className="space-y-2 text-xs">
                  <div className="flex justify-between">
                    <span className="text-slate-600">AI Provider</span>
                    <span className="font-medium text-green-700">OpenAI (Active)</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-600">Fallback Model</span>
                    <span className="font-medium text-slate-700">FastAPI + RandomForest</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-600">Database</span>
                    <span className="font-medium text-green-700">PostgreSQL (Connected)</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-600">API Response Time</span>
                    <span className="font-medium text-slate-700">218ms avg</span>
                  </div>
                </PanelContent>
              </Panel>

              {/* Top Risks */}
              <Panel>
                <PanelHeader>
                  <PanelTitle>Top Risk Locations</PanelTitle>
                </PanelHeader>
                <PanelContent className="space-y-2">
                  {locations.sort((a, b) => b.risk - a.risk).map((loc) => (
                    <div key={loc.id} className="flex items-center justify-between text-sm pb-2 border-b border-slate-100">
                      <div>
                        <div className="font-medium text-slate-900">{loc.name}</div>
                        <div className="text-xs text-slate-600">{loc.predicted.toLocaleString()} predicted</div>
                      </div>
                      <RiskPill risk={loc.risk} />
                    </div>
                  ))}
                </PanelContent>
              </Panel>

              {/* Live Logs */}
              <Panel>
                <PanelHeader>
                  <div className="flex items-center gap-2">
                    <AlertTriangle className="w-4 h-4 text-slate-600" />
                    <PanelTitle>Live System Logs</PanelTitle>
                  </div>
                </PanelHeader>
                <PanelContent>
                  <LogList logs={logs} />
                </PanelContent>
              </Panel>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}