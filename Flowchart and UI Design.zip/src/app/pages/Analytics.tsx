import { Sidebar } from "../components/Sidebar";
import { Panel, PanelHeader, PanelTitle, PanelContent } from "../components/Panel";
import { KPICard } from "../components/KPICard";
import { RiskPill } from "../components/RiskPill";
import { LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";
import { MessageSquare, CheckCircle2, XCircle } from "lucide-react";
import { useState } from "react";

const forecastData = [
  { time: "14:00", footfall: 38000, risk: 72 },
  { time: "15:00", footfall: 40000, risk: 78 },
  { time: "16:00", footfall: 42000, risk: 85 },
  { time: "17:00", footfall: 41000, risk: 82 },
  { time: "18:00", footfall: 38000, risk: 74 },
  { time: "19:00", footfall: 35000, risk: 68 },
  { time: "20:00", footfall: 32000, risk: 58 },
];

const riskBreakdown = [
  { component: "Footfall Pressure", value: 35 },
  { component: "Weather Risk", value: 22 },
  { component: "AQI Impact", value: 12 },
  { component: "Social Spike", value: 10 },
  { component: "Traffic Congestion", value: 6 },
];

const correlationData = [
  { hour: "08:00", traffic: 45, social: 32, footfall: 28000 },
  { hour: "10:00", traffic: 68, social: 58, footfall: 35000 },
  { hour: "12:00", traffic: 82, social: 72, footfall: 40000 },
  { hour: "14:00", traffic: 88, social: 85, footfall: 42000 },
  { hour: "16:00", traffic: 76, social: 68, footfall: 38000 },
];

const locations = [
  { id: 1, name: "Vaishno Devi" },
  { id: 2, name: "Patnitop" },
  { id: 3, name: "Raghunath Temple" },
];

const mitigationActions = [
  { action: "Activate shuttle services", status: "pending" as const },
  { action: "Implement staggered entry (08:00-10:00)", status: "pending" as const },
  { action: "Send weather advisories to visitors", status: "completed" as const },
  { action: "Redirect traffic to alternate routes", status: "pending" as const },
  { action: "Increase parking restrictions", status: "pending" as const },
];

export function Analytics() {
  const [selectedLocation, setSelectedLocation] = useState(locations[0].id);

  return (
    <div className="flex h-screen bg-slate-50">
      <Sidebar />
      <div className="flex-1 overflow-auto">
        <div className="p-6">
          <div className="mb-6 flex items-center justify-between">
            <div>
              <h2 className="text-2xl font-semibold text-slate-900">Location Analytics</h2>
              <p className="text-sm text-slate-600 mt-1">Deep dive into site-specific predictions</p>
            </div>
            <select
              value={selectedLocation}
              onChange={(e) => setSelectedLocation(Number(e.target.value))}
              className="px-4 py-2 border border-slate-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              {locations.map((loc) => (
                <option key={loc.id} value={loc.id}>
                  {loc.name}
                </option>
              ))}
            </select>
          </div>

          {/* KPIs */}
          <div className="grid grid-cols-4 gap-4 mb-6">
            <KPICard label="Current Risk" value="85" sublabel="Critical level" />
            <KPICard label="Predicted Footfall" value="42,000" sublabel="Next 6 hours" />
            <KPICard label="Utilization" value="120%" sublabel="Over capacity" />
            <KPICard label="Sustainability" value="62%" sublabel="Below target" />
          </div>

          <div className="grid grid-cols-3 gap-6">
            {/* Left Column */}
            <div className="col-span-2 space-y-6">
              {/* Forecast Chart */}
              <Panel>
                <PanelHeader>
                  <PanelTitle>12-Hour Footfall & Risk Forecast</PanelTitle>
                </PanelHeader>
                <PanelContent>
                  <ResponsiveContainer width="100%" height={280}>
                    <LineChart data={forecastData}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                      <XAxis dataKey="time" tick={{ fontSize: 12 }} />
                      <YAxis yAxisId="left" tick={{ fontSize: 12 }} />
                      <YAxis yAxisId="right" orientation="right" domain={[0, 100]} tick={{ fontSize: 12 }} />
                      <Tooltip />
                      <Line
                        yAxisId="left"
                        type="monotone"
                        dataKey="footfall"
                        stroke="#3b82f6"
                        strokeWidth={2}
                        name="Footfall"
                      />
                      <Line
                        yAxisId="right"
                        type="monotone"
                        dataKey="risk"
                        stroke="#ef4444"
                        strokeWidth={2}
                        name="Risk Score"
                      />
                    </LineChart>
                  </ResponsiveContainer>
                </PanelContent>
              </Panel>

              {/* Plain English Explanation */}
              <Panel className="bg-amber-50 border-amber-200">
                <PanelHeader>
                  <PanelTitle className="text-amber-900">Plain-English Explanation</PanelTitle>
                </PanelHeader>
                <PanelContent>
                  <p className="text-sm text-amber-900">
                    Based on historical patterns and current indicators, <strong>Vaishno Devi will experience peak crowding at 16:00 today</strong> with an estimated 42,000 visitors—
                    <strong>20% over safe capacity</strong>. Heavy rainfall is expected to begin at 15:30, which will compound safety risks. Social media activity has increased 42% in the last 3 hours, 
                    indicating surge in visitor interest. We recommend immediate intervention to prevent overcrowding and ensure visitor safety.
                  </p>
                </PanelContent>
              </Panel>

              {/* Risk Breakdown */}
              <Panel>
                <PanelHeader>
                  <PanelTitle>Risk Component Breakdown</PanelTitle>
                </PanelHeader>
                <PanelContent>
                  <ResponsiveContainer width="100%" height={220}>
                    <BarChart data={riskBreakdown} layout="vertical">
                      <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                      <XAxis type="number" domain={[0, 40]} tick={{ fontSize: 12 }} />
                      <YAxis dataKey="component" type="category" width={140} tick={{ fontSize: 11 }} />
                      <Tooltip />
                      <Bar dataKey="value" fill="#f59e0b" name="Risk Points" />
                    </BarChart>
                  </ResponsiveContainer>
                </PanelContent>
              </Panel>

              {/* Traffic & Social Correlation */}
              <Panel>
                <PanelHeader>
                  <PanelTitle>Traffic & Social Media Correlation</PanelTitle>
                </PanelHeader>
                <PanelContent>
                  <ResponsiveContainer width="100%" height={220}>
                    <LineChart data={correlationData}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                      <XAxis dataKey="hour" tick={{ fontSize: 12 }} />
                      <YAxis tick={{ fontSize: 12 }} />
                      <Tooltip />
                      <Line type="monotone" dataKey="traffic" stroke="#8b5cf6" strokeWidth={2} name="Traffic Index" />
                      <Line type="monotone" dataKey="social" stroke="#ec4899" strokeWidth={2} name="Social Spike" />
                    </LineChart>
                  </ResponsiveContainer>
                </PanelContent>
              </Panel>
            </div>

            {/* Right Column */}
            <div className="space-y-6">
              {/* Current Status */}
              <Panel className="bg-red-50 border-red-200">
                <PanelHeader>
                  <PanelTitle className="text-red-900">Current Status</PanelTitle>
                </PanelHeader>
                <PanelContent>
                  <div className="flex items-center justify-between mb-3">
                    <span className="text-sm text-red-900">Risk Level</span>
                    <RiskPill risk={85} />
                  </div>
                  <div className="text-xs text-red-800 space-y-1">
                    <div>• Exceeds capacity by 7,000</div>
                    <div>• Weather alert active</div>
                    <div>• High social media activity</div>
                    <div>• Traffic congestion detected</div>
                  </div>
                </PanelContent>
              </Panel>

              {/* Mitigation Checklist */}
              <Panel>
                <PanelHeader>
                  <PanelTitle>Mitigation Checklist</PanelTitle>
                </PanelHeader>
                <PanelContent className="space-y-2">
                  {mitigationActions.map((item, index) => (
                    <div key={index} className="flex items-start gap-2 text-sm pb-2 border-b border-slate-100">
                      {item.status === "completed" ? (
                        <CheckCircle2 className="w-4 h-4 text-green-600 mt-0.5 flex-shrink-0" />
                      ) : (
                        <XCircle className="w-4 h-4 text-slate-300 mt-0.5 flex-shrink-0" />
                      )}
                      <span className={item.status === "completed" ? "text-slate-500 line-through" : "text-slate-700"}>
                        {item.action}
                      </span>
                    </div>
                  ))}
                </PanelContent>
              </Panel>

              {/* Data Sources */}
              <Panel className="bg-slate-50">
                <PanelHeader>
                  <PanelTitle>Data Sources Used</PanelTitle>
                </PanelHeader>
                <PanelContent className="space-y-2 text-xs">
                  <div className="flex justify-between">
                    <span className="text-slate-600">Historical Footfall</span>
                    <span className="font-medium text-green-700">PostgreSQL</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-600">Weather Data</span>
                    <span className="font-medium text-green-700">OpenWeather</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-600">AQI Data</span>
                    <span className="font-medium text-green-700">OpenWeather</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-600">Social Media</span>
                    <span className="font-medium text-green-700">Indexed</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-600">Traffic Index</span>
                    <span className="font-medium text-green-700">Live Feed</span>
                  </div>
                </PanelContent>
              </Panel>

              {/* AI Model Info */}
              <Panel className="bg-blue-50 border-blue-200">
                <PanelHeader>
                  <PanelTitle className="text-blue-900">AI Model Info</PanelTitle>
                </PanelHeader>
                <PanelContent className="space-y-2 text-xs text-blue-800">
                  <div className="flex justify-between">
                    <span>Primary Provider</span>
                    <span className="font-medium">OpenAI</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Fallback Model</span>
                    <span className="font-medium">RandomForest</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Confidence</span>
                    <span className="font-medium">94.2%</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Last Update</span>
                    <span className="font-medium">2 min ago</span>
                  </div>
                </PanelContent>
              </Panel>

              {/* Chatbot CTA */}
              <button
                onClick={() => window.location.href = "/chatbot"}
                className="w-full px-4 py-3 bg-blue-600 hover:bg-blue-700 text-white text-sm rounded-lg transition-colors flex items-center justify-center gap-2"
              >
                <MessageSquare className="w-4 h-4" />
                Open Analytics Chatbot
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
