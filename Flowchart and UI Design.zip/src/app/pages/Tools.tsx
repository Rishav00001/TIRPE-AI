import { Sidebar } from "../components/Sidebar";
import { Panel, PanelHeader, PanelTitle, PanelContent } from "../components/Panel";
import { 
  Code, 
  Database, 
  Brain, 
  Cloud, 
  Layers,
  BarChart3,
  Map,
  Package
} from "lucide-react";

interface Tool {
  category: string;
  icon: any;
  items: { name: string; description: string; color: string }[];
}

const tools: Tool[] = [
  {
    category: "Frontend",
    icon: Code,
    items: [
      { name: "React", description: "UI library via Vite", color: "text-blue-600" },
      { name: "Tailwind CSS", description: "Utility-first styling", color: "text-cyan-600" },
      { name: "Leaflet / OpenStreetMap", description: "Interactive map visualization", color: "text-green-600" },
      { name: "Recharts", description: "Data-driven chart components", color: "text-purple-600" },
      { name: "React Router", description: "Client-side navigation", color: "text-red-600" },
    ],
  },
  {
    category: "Backend",
    icon: Database,
    items: [
      { name: "Node.js", description: "JavaScript runtime", color: "text-green-700" },
      { name: "Express", description: "Web application framework", color: "text-slate-700" },
      { name: "PostgreSQL", description: "Historical footfall database", color: "text-blue-700" },
      { name: "Redis", description: "Optional caching layer", color: "text-red-700" },
      { name: "Zod", description: "Schema validation", color: "text-indigo-700" },
    ],
  },
  {
    category: "AI & Machine Learning",
    icon: Brain,
    items: [
      { name: "OpenAI API", description: "Primary prediction engine", color: "text-green-600" },
      { name: "FastAPI", description: "Fallback model server", color: "text-teal-600" },
      { name: "scikit-learn", description: "RandomForest local model", color: "text-orange-600" },
      { name: "Python", description: "ML model runtime", color: "text-yellow-600" },
    ],
  },
  {
    category: "Data Enrichment",
    icon: Cloud,
    items: [
      { name: "OpenWeather API", description: "Weather + AQI data", color: "text-blue-500" },
      { name: "Social Media Index", description: "Visitor interest tracking", color: "text-pink-600" },
      { name: "Traffic Feed", description: "Real-time congestion data", color: "text-amber-600" },
    ],
  },
  {
    category: "Platform Features",
    icon: Layers,
    items: [
      { name: "Risk Engine", description: "0-100 risk scoring algorithm", color: "text-red-600" },
      { name: "Mitigation Engine", description: "Actionable recommendation system", color: "text-green-600" },
      { name: "Analytics Chatbot", description: "Natural language query interface", color: "text-blue-600" },
      { name: "Operations Console", description: "Live system monitoring", color: "text-slate-600" },
      { name: "Early Warning System", description: "6-12 hour advance alerts", color: "text-yellow-600" },
    ],
  },
];

export function Tools() {
  return (
    <div className="flex h-screen bg-slate-50">
      <Sidebar />
      <div className="flex-1 overflow-auto">
        <div className="p-6">
          <div className="mb-6">
            <h2 className="text-2xl font-semibold text-slate-900">Tools & Technologies</h2>
            <p className="text-sm text-slate-600 mt-1">Complete tech stack for TIRPE AI platform</p>
          </div>

          {/* Overview Cards */}
          <div className="grid grid-cols-4 gap-4 mb-8">
            <div className="bg-white border border-slate-200 rounded-lg p-4">
              <div className="flex items-center gap-2 mb-2">
                <Code className="w-5 h-5 text-blue-600" />
                <div className="text-xs text-slate-500">Frontend</div>
              </div>
              <div className="text-2xl font-semibold text-slate-900">5</div>
              <div className="text-xs text-slate-600 mt-1">Core technologies</div>
            </div>
            <div className="bg-white border border-slate-200 rounded-lg p-4">
              <div className="flex items-center gap-2 mb-2">
                <Database className="w-5 h-5 text-green-700" />
                <div className="text-xs text-slate-500">Backend</div>
              </div>
              <div className="text-2xl font-semibold text-slate-900">5</div>
              <div className="text-xs text-slate-600 mt-1">Server & database</div>
            </div>
            <div className="bg-white border border-slate-200 rounded-lg p-4">
              <div className="flex items-center gap-2 mb-2">
                <Brain className="w-5 h-5 text-purple-600" />
                <div className="text-xs text-slate-500">AI/ML</div>
              </div>
              <div className="text-2xl font-semibold text-slate-900">4</div>
              <div className="text-xs text-slate-600 mt-1">Prediction models</div>
            </div>
            <div className="bg-white border border-slate-200 rounded-lg p-4">
              <div className="flex items-center gap-2 mb-2">
                <Layers className="w-5 h-5 text-amber-600" />
                <div className="text-xs text-slate-500">Platform</div>
              </div>
              <div className="text-2xl font-semibold text-slate-900">5</div>
              <div className="text-xs text-slate-600 mt-1">Custom features</div>
            </div>
          </div>

          {/* Tool Categories */}
          <div className="space-y-6">
            {tools.map((category, idx) => {
              const Icon = category.icon;
              return (
                <Panel key={idx}>
                  <PanelHeader>
                    <div className="flex items-center gap-2">
                      <Icon className="w-5 h-5 text-slate-700" />
                      <PanelTitle>{category.category}</PanelTitle>
                    </div>
                  </PanelHeader>
                  <PanelContent>
                    <div className="grid grid-cols-2 gap-4">
                      {category.items.map((tool, toolIdx) => (
                        <div
                          key={toolIdx}
                          className="flex items-start gap-3 p-3 bg-slate-50 rounded-lg border border-slate-200"
                        >
                          <Package className={`w-5 h-5 ${tool.color} flex-shrink-0 mt-0.5`} />
                          <div className="flex-1">
                            <div className="font-medium text-slate-900 text-sm">{tool.name}</div>
                            <div className="text-xs text-slate-600 mt-0.5">{tool.description}</div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </PanelContent>
                </Panel>
              );
            })}
          </div>

          {/* Architecture Highlights */}
          <div className="mt-8 grid grid-cols-2 gap-6">
            <Panel className="bg-blue-50 border-blue-200">
              <PanelHeader>
                <PanelTitle className="text-blue-900">Key Architecture Decisions</PanelTitle>
              </PanelHeader>
              <PanelContent>
                <ul className="space-y-2 text-sm text-blue-800">
                  <li className="flex items-start gap-2">
                    <span className="text-blue-600 mt-1">•</span>
                    <span><strong>Environment-based AI switching</strong> - Primary OpenAI with local RandomForest fallback for reliability</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-blue-600 mt-1">•</span>
                    <span><strong>Type-safe validation</strong> - Zod schemas ensure data integrity across API boundaries</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-blue-600 mt-1">•</span>
                    <span><strong>Modular risk calculation</strong> - Separate engines for risk scoring and mitigation recommendations</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-blue-600 mt-1">•</span>
                    <span><strong>Real-time enrichment</strong> - Weather and AQI data integrated into prediction pipeline</span>
                  </li>
                </ul>
              </PanelContent>
            </Panel>

            <Panel className="bg-green-50 border-green-200">
              <PanelHeader>
                <PanelTitle className="text-green-900">Platform Capabilities</PanelTitle>
              </PanelHeader>
              <PanelContent>
                <ul className="space-y-2 text-sm text-green-800">
                  <li className="flex items-start gap-2">
                    <span className="text-green-600 mt-1">•</span>
                    <span><strong>6-12 hour prediction window</strong> - Early warning system for proactive decision-making</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-green-600 mt-1">•</span>
                    <span><strong>Plain-language AI summaries</strong> - Accessible insights for non-technical judges and officials</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-green-600 mt-1">•</span>
                    <span><strong>Interactive risk visualization</strong> - Color-coded heatmaps on OpenStreetMap</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-green-600 mt-1">•</span>
                    <span><strong>Chatbot with memory</strong> - Context-aware natural language interface for data queries</span>
                  </li>
                </ul>
              </PanelContent>
            </Panel>
          </div>

          {/* Data Sources */}
          <div className="mt-6">
            <Panel>
              <PanelHeader>
                <div className="flex items-center gap-2">
                  <Map className="w-5 h-5 text-slate-700" />
                  <PanelTitle>Data Sources Integration</PanelTitle>
                </div>
              </PanelHeader>
              <PanelContent>
                <div className="grid grid-cols-3 gap-4">
                  <div className="text-center p-4 bg-slate-50 rounded-lg border border-slate-200">
                    <BarChart3 className="w-6 h-6 text-blue-600 mx-auto mb-2" />
                    <div className="font-medium text-sm text-slate-900">Historical Data</div>
                    <div className="text-xs text-slate-600 mt-1">PostgreSQL database with 2+ years footfall records</div>
                  </div>
                  <div className="text-center p-4 bg-slate-50 rounded-lg border border-slate-200">
                    <Cloud className="w-6 h-6 text-green-600 mx-auto mb-2" />
                    <div className="font-medium text-sm text-slate-900">Live External APIs</div>
                    <div className="text-xs text-slate-600 mt-1">OpenWeather for real-time weather + AQI enrichment</div>
                  </div>
                  <div className="text-center p-4 bg-slate-50 rounded-lg border border-slate-200">
                    <Layers className="w-6 h-6 text-purple-600 mx-auto mb-2" />
                    <div className="font-medium text-sm text-slate-900">Derived Signals</div>
                    <div className="text-xs text-slate-600 mt-1">Social media spike index and traffic congestion metrics</div>
                  </div>
                </div>
              </PanelContent>
            </Panel>
          </div>

          {/* Version Info */}
          <div className="mt-6 text-center text-xs text-slate-500">
            <div>TIRPE AI Platform • Version 1.0.0</div>
            <div className="mt-1">Built for government-grade tourism risk management</div>
          </div>
        </div>
      </div>
    </div>
  );
}
