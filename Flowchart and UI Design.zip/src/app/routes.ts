import { createBrowserRouter } from "react-router";
import { Dashboard } from "./pages/Dashboard";
import { Analytics } from "./pages/Analytics";
import { Chatbot } from "./pages/Chatbot";
import { Flowchart } from "./pages/Flowchart";
import { Tools } from "./pages/Tools";

export const router = createBrowserRouter([
  {
    path: "/",
    Component: Dashboard,
  },
  {
    path: "/analytics",
    Component: Analytics,
  },
  {
    path: "/chatbot",
    Component: Chatbot,
  },
  {
    path: "/flowchart",
    Component: Flowchart,
  },
  {
    path: "/tools",
    Component: Tools,
  },
]);
