import { useEffect, useRef } from "react";
import L from "leaflet";
import "leaflet/dist/leaflet.css";

interface Location {
  id: number;
  name: string;
  lat: number;
  lng: number;
  risk: number;
  predicted: number;
  capacity: number;
}

interface RiskMapProps {
  locations: Location[];
}

export function RiskMap({ locations }: RiskMapProps) {
  const mapRef = useRef<HTMLDivElement>(null);
  const mapInstanceRef = useRef<L.Map | null>(null);

  useEffect(() => {
    if (!mapRef.current || mapInstanceRef.current) return;

    // Initialize map
    const map = L.map(mapRef.current).setView([32.95, 74.95], 9);
    mapInstanceRef.current = map;

    // Add tile layer
    L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
      attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>',
    }).addTo(map);

    // Add markers
    locations.forEach((loc) => {
      const color = loc.risk < 40 ? "#22c55e" : loc.risk < 70 ? "#eab308" : "#ef4444";

      const marker = L.circleMarker([loc.lat, loc.lng], {
        radius: 12,
        fillColor: color,
        color: "#fff",
        weight: 2,
        fillOpacity: 0.8,
      }).addTo(map);

      marker.bindPopup(`
        <div style="font-size: 12px;">
          <div style="font-weight: 600; margin-bottom: 4px;">${loc.name}</div>
          <div>Risk: ${loc.risk}</div>
          <div>Predicted: ${loc.predicted.toLocaleString()}</div>
          <div>Capacity: ${loc.capacity.toLocaleString()}</div>
        </div>
      `);
    });

    // Cleanup
    return () => {
      if (mapInstanceRef.current) {
        mapInstanceRef.current.remove();
        mapInstanceRef.current = null;
      }
    };
  }, [locations]);

  return <div ref={mapRef} className="h-full w-full" />;
}
