import { Link, useLocation } from "react-router";
import { 
  LayoutDashboard, 
  BarChart3, 
  MessageSquare, 
  GitBranch,
  Wrench
} from "lucide-react";

export function Sidebar() {
  const location = useLocation();
  
  const links = [
    { path: "/", icon: LayoutDashboard, label: "Dashboard" },
    { path: "/analytics", icon: BarChart3, label: "Analytics" },
    { path: "/chatbot", icon: MessageSquare, label: "Chatbot" },
    { path: "/flowchart", icon: GitBranch, label: "Flowchart" },
    { path: "/tools", icon: Wrench, label: "Tools" },
  ];

  return (
    <div className="w-64 bg-slate-800 text-white flex flex-col">
      <div className="p-6 border-b border-slate-700">
        <h1 className="text-xl font-semibold">TIRPE AI</h1>
        <p className="text-xs text-slate-400 mt-1">Tourism Intelligence Engine</p>
      </div>
      <nav className="flex-1 p-4">
        <ul className="space-y-2">
          {links.map((link) => {
            const Icon = link.icon;
            const isActive = location.pathname === link.path;
            return (
              <li key={link.path}>
                <Link
                  to={link.path}
                  className={`flex items-center gap-3 px-4 py-2.5 rounded-lg transition-colors ${
                    isActive
                      ? "bg-slate-700 text-white"
                      : "text-slate-300 hover:bg-slate-700/50"
                  }`}
                >
                  <Icon className="w-5 h-5" />
                  <span>{link.label}</span>
                </Link>
              </li>
            );
          })}
        </ul>
      </nav>
      <div className="p-4 border-t border-slate-700 text-xs text-slate-400">
        <div>AI Provider: OpenAI</div>
        <div className="mt-1">Version 1.0.0</div>
      </div>
    </div>
  );
}
