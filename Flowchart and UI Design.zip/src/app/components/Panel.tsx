import React from "react";

interface PanelProps {
  children: React.ReactNode;
  className?: string;
}

export function Panel({ children, className = "" }: PanelProps) {
  return (
    <div className={`bg-white border border-slate-200 rounded-lg p-4 ${className}`}>
      {children}
    </div>
  );
}

interface PanelHeaderProps {
  children: React.ReactNode;
  className?: string;
}

export function PanelHeader({ children, className = "" }: PanelHeaderProps) {
  return <div className={`mb-3 ${className}`}>{children}</div>;
}

interface PanelTitleProps {
  children: React.ReactNode;
  className?: string;
}

export function PanelTitle({ children, className = "" }: PanelTitleProps) {
  return <h3 className={`font-semibold text-slate-800 ${className}`}>{children}</h3>;
}

interface PanelContentProps {
  children: React.ReactNode;
  className?: string;
}

export function PanelContent({ children, className = "" }: PanelContentProps) {
  return <div className={className}>{children}</div>;
}
