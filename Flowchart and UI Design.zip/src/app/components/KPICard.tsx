interface KPICardProps {
  label: string;
  value: string | number;
  sublabel?: string;
  className?: string;
}

export function KPICard({ label, value, sublabel, className = "" }: KPICardProps) {
  return (
    <div className={`bg-white border border-slate-200 rounded-lg p-4 ${className}`}>
      <div className="text-xs text-slate-500 mb-1">{label}</div>
      <div className="text-2xl font-semibold text-slate-900">{value}</div>
      {sublabel && <div className="text-xs text-slate-600 mt-1">{sublabel}</div>}
    </div>
  );
}
