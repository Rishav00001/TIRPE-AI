import { Clock } from "lucide-react";

interface LogEntry {
  time: string;
  message: string;
  type: "info" | "warning" | "error";
}

interface LogListProps {
  logs: LogEntry[];
}

export function LogList({ logs }: LogListProps) {
  const getLogColor = (type: LogEntry["type"]) => {
    switch (type) {
      case "warning":
        return "text-yellow-600";
      case "error":
        return "text-red-600";
      default:
        return "text-slate-600";
    }
  };

  return (
    <div className="space-y-2">
      {logs.map((log, index) => (
        <div key={index} className="text-xs flex items-start gap-2 pb-2 border-b border-slate-100">
          <Clock className="w-3 h-3 text-slate-400 mt-0.5 flex-shrink-0" />
          <div className="flex-1">
            <div className="text-slate-400">{log.time}</div>
            <div className={`mt-0.5 ${getLogColor(log.type)}`}>{log.message}</div>
          </div>
        </div>
      ))}
    </div>
  );
}
