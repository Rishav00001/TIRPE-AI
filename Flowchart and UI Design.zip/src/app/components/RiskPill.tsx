interface RiskPillProps {
  risk: number;
  className?: string;
}

export function RiskPill({ risk, className = "" }: RiskPillProps) {
  const getRiskLevel = (score: number) => {
    if (score < 40) return { label: "Green", color: "bg-green-100 text-green-800 border-green-300" };
    if (score < 70) return { label: "Yellow", color: "bg-yellow-100 text-yellow-800 border-yellow-300" };
    return { label: "Red", color: "bg-red-100 text-red-800 border-red-300" };
  };

  const riskLevel = getRiskLevel(risk);

  return (
    <span
      className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md text-xs font-medium border ${riskLevel.color} ${className}`}
    >
      <span className="w-1.5 h-1.5 rounded-full bg-current"></span>
      {riskLevel.label} ({risk})
    </span>
  );
}
