
  # Flowchart and UI Design

  This is a code bundle for Flowchart and UI Design. The original project is available at https://www.figma.com/design/Thp7THH23z1ILWwm6ZyKxf/Flowchart-and-UI-Design.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  